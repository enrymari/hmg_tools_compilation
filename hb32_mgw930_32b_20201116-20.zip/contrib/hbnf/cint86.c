#include "hbapi.h"

HB_FUNC( FT_INT86 )
{
#if defined( HB_OS_DOS )
   {
      int iTODO;
   }
#endif
   hb_retl( HB_FALSE );
}
