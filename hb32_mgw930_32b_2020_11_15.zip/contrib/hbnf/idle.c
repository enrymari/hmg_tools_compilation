/*
 * Author....: Ted Means (with much gratitude to Robert DiFalco)
 * CIS ID....: 73067,3332
 *
 * This function is an original work by Ted Means and is placed in the
 * public domain.
 *
 * Modification history:
 * ---------------------
 *
 *    Rev 1.0   01 Jan 1995 03:01:00   TED
 * Initial release
 *
 */

#include "hbapi.h"

HB_FUNC( FT_IDLE )
{
   hb_idleState();
}
