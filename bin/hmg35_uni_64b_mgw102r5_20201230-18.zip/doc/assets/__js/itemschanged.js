function addmoditem()
{
modified = new Array();
modified.push(("Building_HMG_applications.htm").toLowerCase());
modified.push(("tutorial.htm").toLowerCase());
modified.push(("tutorial_es.htm").toLowerCase());
modified.push(("faq.htm").toLowerCase());
modified.push(("idebasics.htm").toLowerCase());
modified.push(("idequickstart.htm").toLowerCase());
modified.push(("definewindow.htm").toLowerCase());
modified.push(("grid.htm").toLowerCase());
modified.push(("OnKey_Grid.htm").toLowerCase());
modified.push(("inputwindow.htm").toLowerCase());
modified.push(("HMG_HPDF%20Introduction.htm").toLowerCase());
modified.push(("HMG_HPDF_Document_Handling.htm").toLowerCase());
modified.push(("HMG_HPDFINFO.htm").toLowerCase());
modified.push(("HMG_HPDFMiscellaneous.htm").toLowerCase());
modified.push(("HMG_HPDFOutline.htm").toLowerCase());
modified.push(("HMG_HPDFPage_Handling.htm").toLowerCase());
modified.push(("HMG_HPDFContent_Handling.htm").toLowerCase());
modified.push(("HMG_GetDLLFunctions.htm").toLowerCase());
modified.push(("HMG_GetHBSymbols.htm").toLowerCase());
modified.push(("HMG_GetCompileVersion32.htm").toLowerCase());
modified.push(("HMG_GetCompileVersion64.htm").toLowerCase());
modified.push(("DisableProcessWindowsGhosting.htm").toLowerCase());
modified.push(("BosTaurus-FunctionsReferenceGuide.htm").toLowerCase());
modified.push(("hmgdoc.htm").toLowerCase());
modified.push(("index.html").toLowerCase());
modified.push(("OurChannel.htm").toLowerCase());
return modified;
}