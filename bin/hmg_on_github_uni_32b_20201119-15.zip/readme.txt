
HMG: xBase Development System For Windows
-----------------------------------------

HMG is the union of these main components:

	- HMG Library and preprocessor directives
	- HMG IDE
	- MingW Compiler
	- Harbour Compiler

All together, these tools conform a completely free xBase Windows development
system, combining the traditional xBase, with an extremely easy to use GUI.

HMG can be downloaded at: 

	http://www.hmgforum.com


Copyright (C) 2002-2010 Roberto Lopez. All rights reserved.


Enjoy!

--HMGFORUM-2020
Roberto Lopez <mail.box.hmg@gmail.com>



